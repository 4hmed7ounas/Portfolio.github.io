﻿//L216025, L217687 Project
#include<iostream>
#include<fstream>
#include<queue>
#include<stack>
#include<Windows.h>
#include<thread>
using namespace std;
class Info 
{ // adding details
private:
	string fname;
	string lname;
	char address;
	string email;
	string num;
	string* cuisines;
	string dishes;
	int* time;
	int order;
public:
	Info();
	char getAddress();
	int getOrder();
	int AddDetails();
	void AddDishes();
};
Info::Info() 
{
	fname = " ";
	lname = " ";
	address = ' ';
	email = " ";
	num = " ";
	dishes = " ";
	order = 0;
	time = new int[5];
	cuisines = new string[5];
	for (int i = 0; i < 5; i++)
	{
		time[i] = 0;
		cuisines[i] = " ";
	}
}
char Info::getAddress()
{
	return address;
}
int Info::getOrder() 
{
	return order;
}
int Info::AddDetails() 
{ // customer details & order assigning
	fstream var;
	int Cuissize;
	cout << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<WELCOME TO FAVIOURITE PANDA>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" << endl;
	var.open("Data.txt", ios::app);
	cout << "------------------------------------------------------------------------------------------" << endl;
	cout << "Order " << order + 1 << ": " << endl;
	cout << "Enter Name: ";
	cin >> fname >> lname;
	cout << "Enter Address: ";
	cin >> address;
	while (address < 'A' || address > 'P' || address == 'H') 
	{
		cout << "Out of our range: ";
		cin >> address;
	}
	cout << "Enter Email: ";
	cin >> email;
	cout << "Enter Phone Number: ";
	cin >> num;
	var << "ORDER " << order + 1 << ": " << endl;
	var << "INFO: \nName: " << fname << " " << lname << "\nAddress: " << address << "\nEmail: " << email << "\nPhone: " << num << endl;
	cout << "------------------------------------------------------------------------------------------" << endl;
	cout << "1- Continental, 2- Chinese, 3- Thai, 4- Italian, 5- Indian." << endl;
	cout << "How Many Cuisnies you want: ";
	cin >> Cuissize;
	while (Cuissize < 1 || Cuissize > 5)
	{
		cout << "We only have 5 cuisines, How Many Cuisnies you want?: ";
		cin >> Cuissize;
	}
	for (int i = 0; i < Cuissize; i++) 
	{
		cout << "Enter Cuisines " << i + 1 << ": ";
		cin >> cuisines[i];
		while (cuisines[i] != "Continental" && cuisines[i] != "Chinese" && cuisines[i] != "Thai" && cuisines[i] != "Italian" && cuisines[i] != "Indian") {
			cout << "You have Entered the wrong cuisine, Enter Cuisines again: ";
			cin >> cuisines[i];
		}
		var << "CUISINE: " << cuisines[i] << endl;
		if (cuisines[i] == "Continental") 
		{
			time[i] = 20;
			cout << "1-PaneerSteak, 2-CheeseFondue, 3-BroccoliBake, 4-ChickenSalad." << endl;
			AddDishes();
		}
		else if (cuisines[i] == "Chinese") 
		{
			time[i] = 25;
			cout << "Dishes:" << endl;
			cout << "1-ChowMein, 2-HotPot, 3-Dumplings, 4-Manchurian." << endl;
			AddDishes();
		}
		else if (cuisines[i] == "Thai") 
		{
			time[i] = 35;
			cout << "Dishes:" << endl;
			cout << "1-YamNua, 2-MassamanCurry, 3-PadWoonSen, 4-KaoKaMoo." << endl;
			AddDishes();
		}
		else if (cuisines[i] == "Italian") 
		{
			time[i] = 25;
			cout << "Dishes:" << endl;
			cout << "1-Pizza, 2-Bottarga, 3-Risotto, 4-Polenta." << endl;
			AddDishes();
		}
		else if (cuisines[i] == "Indian") 
		{
			time[i] = 15;
			cout << "Dishes:" << endl;
			cout << "1-VadaPao, 2-Dhokla, 3-MasalaDosa, 4-StuffedParatha." << endl;
			AddDishes();
		}
		cout << "------------------------------------------------------------------------------------------" << endl;
	}
	// finding max time
	for (int i = 0; i < Cuissize; i++) 
	{
		for (int j = i + 1; j < Cuissize; j++) 
		{
			if (time[i] < time[j]) 
			{
				swap(time[i], time[j]);
			}
		}
	}
	order++;
	return time[0];
}
void Info::AddDishes() 
{ // adding dishes
	int ds;
	fstream dis;
	dis.open("Data.txt", ios::app);
	cout << "How Many dishes you want: ";
	cin >> ds;
	while (ds < 1 || ds > 4) 
	{
		cout << "We only have 4 dished, How Many dishes you want?: ";
		cin >> ds;
	}
	for (int i = 0; i < ds; i++)
	{
		cout << "Enter Dish " << i + 1 << ": " << endl;
		cin >> dishes;
		dis << "Dish " << i + 1 << ": " << dishes << endl;
	}
}
template<class T>
class Graph {
public:
	Graph(int numVertex) 
	{
		numVertices = numVertex;
		adj_matrix = new int* [numVertex];
		matrix = new char* [numVertex];
		for (int i = 0; i < numVertices; i++) 
		{
			matrix[i] = new char[numVertices];
			adj_matrix[i] = new int[numVertices];
			for (int j = 0; j < numVertices; j++) 
			{
				adj_matrix[i][j] = 0;
				matrix[i][j] = '0';
			}
		}
	}
	int GetNumVertices() 
	{
		return numVertices;
	}
	int numberOfEdges() 
	{
		return (numVertices - 1);
	}
	void insertEdge(T frmVertex, T toVertex, int weight) 
	{
		int x = frmVertex - 65;
		int y = toVertex - 65;
		// adj_matrix with weight
		adj_matrix[x][y] = weight;
		adj_matrix[y][x] = weight;
		// matrix with char
		matrix[x][y] = toVertex;
		matrix[y][x] = frmVertex;
	}
	void removeEdge(T frmVertex, T toVertex) 
	{
		int x = frmVertex - 65;
		int y = toVertex - 65;
		adj_matrix[x][y] = 0;
		adj_matrix[x][y] = 0;
	}
	int degree(T v) {
		int vertex = v - 65;
		int count = 0;
		for (int i = vertex; i <= vertex; i++) 
		{
			for (int j = 0; j < numVertices; j++)
			{
				if (adj_matrix[i][j] != 0) 
				{
					count++;
				}
			}
		}
		return count;
	}
	void print() 
	{
		for (int i = 0; i < numVertices; i++) 
		{
			for (int j = 0; j < numVertices; j++) 
			{
				cout << matrix[i][j] << " ";
			}
			cout << endl;
		}
	}
	// path1
	void depthfirstSearch(T start, T desti) 
	{
		int s = start - 65;
		int d = desti - 65;
		bool* vertexCheck = new bool[numVertices];
		bool* reach = new bool[numVertices];
		for (int i = 0; i < numVertices; i++)
		{
			reach[i] = false;
			vertexCheck[i] = false;
		}
		stack<int> st;
		st.push(s);
		reach[s] = true;
		bool path = false;
		while (!st.empty()) 
		{
			int v = st.top();
			char x = v + 65;
			if (vertexCheck[v] == false)
			{
				cout << x << " ";
			}
			if (v == d) 
			{
				return;
			}
			vertexCheck[v] = true;
			for (int i = 0; i < numVertices; i++) 
			{
				if (adj_matrix[v][i] != 0 && reach[i] == false) 
				{
					st.push(i);
					reach[i] = true;
					path = true;
					break;
				}
			}
			if (path == false)
			{
				st.pop();
			}
			path = false;
		}
	}
	// path2
	void breadthfirstSearch(T start, T desti) 
	{
		int s = start - 65;
		int d = desti - 65;
		bool* reach = new bool[numVertices];
		for (int i = 0; i < numVertices; i++) 
		{
			reach[i] = false;
		}
		queue<int> qu;
		qu.push(s);
		reach[s] = true;
		while (!qu.empty()) 
		{
			int v = qu.front();
			char x = v + 65;
			cout << x << " ";
			if (v == d) 
			{
				return;
			}
			for (int i = 0; i < numVertices; i++) 
			{
				if (adj_matrix[v][i] != 0 && reach[i] == false) 
				{
					qu.push(i);
					reach[i] = true;
				}
			}
			qu.pop();
		}
	}
	//shortest path
	void ShortestPath(T start, T desti) 
	{
		bool* reach = new bool[numVertices];
		for (int i = 0; i < numVertices; i++)
		{
			reach[i] = false;
		}
		queue<char> q;
		q.push(start);
		int s = start - 65;
		reach[s] = true;
		q.pop();
		cout << start << " ";
		if (desti == 'A' || desti == 'B' || desti == 'C' || desti == 'O')
		{
			q.push('C');
			s = 'C' - 65;
			reach[s] = true;
		}
		else if (desti == 'D' || desti == 'M' || desti == 'L' ) 
		{
			q.push('D');
			s = 'D' - 65;
			reach[s] = true;
		}
		else if (desti == 'E' || desti == 'F')
		{
			q.push('E');
			s = 'E' - 65;
			reach[s] = true;
		}
		else 
		{
			q.push('I');
			s = 'I' - 65;
			reach[s] = true;
		}
		while (!q.empty()) 
		{
			char v = q.front();
			int x = v - 65;
			cout << v << " ";
			if (v == desti)
			{
				return;
			}
			q.pop();
			bool check = false;
			for (int i = 0; i < numVertices; i++) 
			{
				if (matrix[x][i] == desti) 
				{
					check = true;
				}
			}
			if (check) 
			{
				q.push(desti);
			}
			else if (!check)
			{
				for (int i = 0; i < numVertices; i++) 
				{
					if (matrix[x][i] != '0' && reach[i] == false) 
					{
						q.push(matrix[x][i]);
						reach[i] = true;
						break;
					}
				}
			}
		}
	}
private:
	char** matrix;
	int** adj_matrix;
	int numVertices;
};
// storing map from file to graph
void fileAdding(Graph<char>* g) 
{
	ifstream var;
	char x, y;
	int w;
	var.open("mapfile.txt");
	while (!var.eof())
	{
		var >> x >> y >> w;
		g->insertEdge(x, y, w);
	}
}
// function for sleeping
void timer(int x)
{
	int seconds = 0;
	if (x == 25)
	{
		while (seconds != x)
		{
			Sleep(1000);
			seconds++;
		}
	}
	else {
		while (seconds != 4 * x)
		{
			Sleep(1000);
			seconds++;
		}
	}
}
class ChefRiders 
{
private:
	bool chef[4];
	bool riders[5];
public:
	ChefRiders() 
	{
		for (int i = 0; i < 4; i++) 
		{
			chef[i] = false;
		}
		for (int i = 0; i < 5; i++) 
		{
			riders[i] = false;
		}
	}
	void settingChefs() 
	{
		Graph<char>* g;
		g = new Graph<char>(16);
		Info info;
		static int i = 0; // chefs
		static int s = 0; // riders
		fileAdding(g);

		
		//g->print();
		//g->ShortestPath('H','P');
		while (true) 
		{
			thread t2(ChefRiders(), info, g, i, s);
			t2.join();
			break;
		}
	}
	// order taking operator for threading
	void operator()(Info info, Graph<char>* g, int i, int s) 
	{
		int x;
		queue<int> q;
		int t = 0;
		cout << "To order Enter 1." << endl;
		cout << "To exit Enter 2." << endl;
		cin >> x;
		if (x == 1) 
		{
			if (i == 4 || s == 5) 
			{
				i = 0;
				s = 0;
			}
			t = info.AddDetails();
			cout << "Thanks for ordering, it will take " << t << " mints to ready!" << endl;
			q.push(info.getOrder());
			cout << "Order " << info.getOrder() << " has been taken by chef " << i + 1 << endl;
			cout << "------------------------------------------------------------------------------------------" << endl;
			i++;
			s++;
			thread t1(ChefRiders(), t, i - 1, g, info, q, s-1); // to assign chefs 
			thread t2(ChefRiders(), info, g, i, s); // order taking one / recursively
			t1.join();
			t2.join();
			cout << endl;
		}
		if (x == 2)
		{
			return;
		}
	}
	void operator()(int t, int i, Graph<char>* g, Info info, queue<int> q, int s) 
	{  // to assign chefs 
		if (chef[i] == false) 
		{
			chef[i] = true;
			timer(t);
			chef[i] = false;
			cout << endl;
			cout << endl;
			cout << endl;
			cout << "------------------------------------------------------------------------------------------" << endl;
			cout << "\nOrder " << info.getOrder() << " is ready to move & chef " << i + 1 << " is free." << endl;
			q.pop();
			cout << "Path 1: ";
			g->breadthfirstSearch('H', info.getAddress());
			cout << endl;
			cout << "Path 2: ";
			g->depthfirstSearch('H', info.getAddress());
			cout << endl;
			cout << "Path 3: ";
			g->ShortestPath('H', info.getAddress());
			cout << endl;
			cout << "------------------------------------------------------------------------------------------" << endl;
			Beep(1000, 200);
			Sleep(1000);
			Beep(1000, 200);
			cout << "Which path you choose? (1,2,3): ";
			int x;
			srand(time(0));
			x = 1 + rand() % 3; // assigning random paths
			cout << x <<" is the best one, There could be trafic on other paths." << endl;
			cout << endl;
			cout << "The order is taken by Rider " << s + 1 << endl;
			cout << "The order will be served shortly!" << endl;
			cout << "------------------------------------------------------------------------------------------" << endl;
			cout << endl;
			cout << endl;
			cout << endl;
			thread t1(ChefRiders(), s); // assigning riders through thread
			t1.join();
		}
	}
	void operator()(int s)
	{ // assigning riders through thread
		riders[s] = true;
		timer(25);
		riders[s] = false;
		cout << endl;
		cout << endl;
		cout << "Rider " << s + 1 << " is avalible now!" << endl;
		cout << endl;
		cout << endl;
	}
};
int main() 
{
	cout << "------------------------------------------------------------------------------------------" << endl;
	ChefRiders cr;
	cr.settingChefs();
	cout << "------------------------------------------------------------------------------------------" << endl;
	return 0;
}